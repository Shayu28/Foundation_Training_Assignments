﻿namespace TechShop.util
{
    public static class DatabaseConfig
    {
        // Update your connection string here
        public static string ConnectionString => "Server=Shayu;Database=TechShop;Trusted_Connection=True;TrustServerCertificate=True;";
    }
}
